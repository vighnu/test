using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.DirectoryServices;
using System.IO;

namespace WinApp
{
    public partial class ProcessController : Form
    {        
        private string []domains = {"india"};
        private string userName;
        private string password;
        private string machineName;
        private string myDomain;
        private string[] columnNames = { "Caption", "ComputerName", 
            "Description", "Name", "Priority", "ProcessID", "SessionId" };        
        private Hashtable hs = new Hashtable();
        private ManagementScope myScope;
        private ConnectionOptions connOptions;
        private ManagementObjectSearcher objSearcher;
        private ManagementOperationObserver opsObserver;
        private ManagementClass manageClass;
        private DirectoryEntry entry;
        private DirectorySearcher searcher;
        private DirectorySearcher userSearcher;
        private DataTable dt;
        private DataColumn []dc = new DataColumn[7];

        public ProcessController()
        {
            dt = new DataTable();
            for (int i = 0; i < columnNames.Length; i++)
            {
                dc[i] = new DataColumn(columnNames[i], typeof(string));
            }
            dt.Columns.AddRange(dc);

            InitializeComponent();
            foreach (string domain in domains)
            {                
                cmbDomainList.Items.Add(domain);
            }            
            cmbDomainList.SelectedIndex = 0;            
        }     

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (cmdMachinesInDomain.Text == string.Empty)
            {
                MessageBox.Show("Please select machine name");
                return;
            }
            this.Cursor = Cursors.WaitCursor;
            ConnectToRemoteMachine();
        }

        private void terminateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dataGridView1.CurrentRow;
            try
            {
                string endProc = row.Cells[0].Value.ToString().Trim();
                foreach (ManagementObject obj in objSearcher.Get())
                {
                    string caption = obj.GetText(TextFormat.Mof).Trim();
                    if (caption.Contains(endProc.Trim()))
                    {
                        obj.InvokeMethod(opsObserver, "Terminate", null);
                    }
                }
                dataGridView1.Refresh();
                btnConnect_Click(btnConnect, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }       
        

        private void btnGetMachines_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            
            int index = 0;
            // Create an entry for domain
            entry = new DirectoryEntry("LDAP://" + cmbDomainList.Text);
            // Create a user searcher by using filter
            userSearcher = new DirectorySearcher(entry);
            userSearcher.Filter = ("(objectclass=user)");
            SearchResultCollection src = userSearcher.FindAll();            

            // Get all computers
            searcher = new DirectorySearcher(entry);
            searcher.Filter = ("(objectclass=computer)");
            
            try
            {
                SearchResultCollection results = searcher.FindAll();
                foreach (SearchResult sr in results)
                {
                    DirectoryEntry de = sr.GetDirectoryEntry();
                    cmdMachinesInDomain.Items.Add(de.Name.Remove(0,3));

                    DirectoryEntry de1 = src[index++].GetDirectoryEntry();
                    cmbUsers.Items.Add(de1.Properties["cn"].Value.ToString());
                    if (!hs.ContainsKey(de.Name))
                    {
                        hs.Add(de.Name.Remove(0, 3), de1.Properties["cn"].Value.ToString());
                    }
                }
                cmdMachinesInDomain.SelectedIndex = 0;                
                cmbUsers.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void cmdMachinesInDomain_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbUsers.Items.Clear();
            cmbUsers.Text = hs[cmdMachinesInDomain.Text].ToString();
            cmbUsers.Items.Add(hs[cmdMachinesInDomain.Text].ToString());
            cmbUsers.SelectedIndex = 0;
        }

        private void btnEndProcess_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                terminateToolStripMenuItem_Click(sender, e);
                ConnectToRemoteMachine();
            }
        }

        private void ConnectToRemoteMachine()
        {            
            int width = dataGridView1.Width;
            int singleColWidth;          

            singleColWidth = width / dt.Columns.Count;

            userName = txtUserName.Text.Trim();
            password = txtPassword.Text.Trim();
            if (cmdMachinesInDomain.SelectedItem != null)
            {
                machineName = cmdMachinesInDomain.SelectedItem.ToString();
            }
            else if (cmdMachinesInDomain.SelectedText != string.Empty)
            {
                machineName = cmdMachinesInDomain.SelectedText;
            }
            else
            {
                machineName = cmdMachinesInDomain.Text;
            }

            myDomain = cmbDomainList.Text;

            try
            {
                connOptions = new ConnectionOptions();
                connOptions.Impersonation = ImpersonationLevel.Impersonate;
                connOptions.EnablePrivileges = true;
                if (machineName.ToUpper() == Environment.MachineName.ToUpper())
                {
                    myScope = new ManagementScope(@"\ROOT\CIMV2", connOptions);
                }
                else
                {
                    if (chkUseDomain.Checked)
                    {
                        connOptions.Username = myDomain + "\\" + userName;
                    }
                    else
                    {
                        connOptions.Username = machineName + "\\" + userName;
                    }
                    connOptions.Password = password;
                    myScope = new ManagementScope(@"\\" + machineName + @"\ROOT\CIMV2", connOptions);
                }

                myScope.Connect();
                objSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Process");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;
                string[] sep = { "\n", "\t" };
                toolStripStatusLabel1.Text = string.Empty;
                toolStripStatusLabel1.Text = "Authentication sucessful. Getting processes..";
                dt.Rows.Clear();                
                foreach (ManagementObject obj in objSearcher.Get())
                {
                    string caption = obj.GetText(TextFormat.Mof);
                    string[] split = caption.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                    DataRow dr = dt.NewRow();
                    // Iterate through the splitter
                    for (int i = 0; i < split.Length; i++)
                    {
                        if (split[i].Split('=').Length > 1)
                        {
                            string []procDetails = split[i].Split('=');
                            procDetails[1] = procDetails[1].Replace(@"""", "");
                            procDetails[1] = procDetails[1].Replace(';', ' ');
                            switch (procDetails[0].Trim().ToLower())
                            {
                                case "caption":
                                    dr[dc[0]] = procDetails[1];
                                    break;
                                case "csname":
                                    dr[dc[1]] = procDetails[1];
                                    break;
                                case "description":
                                    dr[dc[2]] = procDetails[1];
                                    break;
                                case "name":
                                    dr[dc[3]] = procDetails[1];
                                    break;
                                case "priority":
                                    dr[dc[4]] = procDetails[1];
                                    break;
                                case "processid":
                                    dr[dc[5]] = procDetails[1];
                                    break;
                                case "sessionid":
                                    dr[dc[6]] = procDetails[1];
                                    break;
                            }
                        }
                    }
                    dt.Rows.Add(dr);
                }
                bindingSource1.DataSource = dt.DefaultView;
                foreach (DataColumn col in dt.Columns)
                {
                    DataGridViewTextBoxColumn dvc = new DataGridViewTextBoxColumn();
                    dvc.ToolTipText = col.ColumnName;
                    dvc.Name = col.ColumnName;
                    dvc.HeaderText = col.ColumnName;
                    dvc.DataPropertyName = col.ColumnName;
                    dvc.Width = singleColWidth;
                    dataGridView1.Columns.Add(dvc);
                }
                grpStartNewProcess.Enabled = true;
                btnEndProcess.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void btnStartNew_Click(object sender, EventArgs e)
        {
            object[] arrParams = {txtNewProcess.Text.Trim()};
            try
            {
                manageClass =
                    new ManagementClass(myScope,
                    new ManagementPath("Win32_Process"), new ObjectGetOptions());
                manageClass.InvokeMethod("Create", arrParams);
                btnConnect_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}