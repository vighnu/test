import {Component} from '@angular/core';
import {SearchService} from '../../services/searchService';


@Component({
    selector:'search-emitter',
    template:`
    <div>
        <input type="text" (keyup)="onkeyup($event)" />
    </div>
    `
})
export class SearchEmitterComponent{

    constructor(private searchService:SearchService ){

    }

    public onkeyup(event:any){
               this.searchService.setSearchString(event.target.value);
    }

}
