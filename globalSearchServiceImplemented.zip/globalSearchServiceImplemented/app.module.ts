import {NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CreateNewFicheComponent } from "./components/CreateNewFicheComponent/CreateNewFicheComponent";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
// import ng2-bootstrap alerts module
 
import { Ng2BootstrapModule } from 'ngx-bootstrap/ng2-bootstrap';
// import { AlertModule } from 'node_modules/ngx-bootstrap/alert/';
import { AlertModule } from 'ngx-bootstrap/ng2-bootstrap';
import { ModalModule } from 'ngx-bootstrap/ng2-bootstrap';
import {GroupManagementService} from './services/GlobalGroupService' 
 import { PaginationModule } from 'ngx-bootstrap/ng2-bootstrap';
 import { GridModule }   from './components/grid/grid.module';
import {SearchService} from './services/searchService';
import {SearchEmitterComponent} from './components/searchEmitterComponent/searchEmitter';
import {SearchObserver} from './components/searchObserverComponent/searchObserver';


@NgModule({
    imports:[BrowserModule,NgbModule.forRoot()
    ,Ng2BootstrapModule
    ,AlertModule.forRoot()
    ,ModalModule.forRoot() 
    ,GridModule
    
    ],
    declarations:[CreateNewFicheComponent,SearchEmitterComponent,SearchObserver],
    providers:[GroupManagementService,SearchService],
    bootstrap:[CreateNewFicheComponent]
})

export class AppModule{

}

