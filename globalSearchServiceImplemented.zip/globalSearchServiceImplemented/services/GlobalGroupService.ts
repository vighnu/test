import {Injectable} from '@angular/core';
import * as _ from 'underscore';
 import {Entities} from '../entities/commonEntities';  
  

@Injectable()
export class GroupManagementService{
    private currentGroupId:string='';
private dataForGlobalView: Array<Entities.IDataForGlobalView> = [
    {ccgId:'1',clientId:'123456',fullName:'-',status:Entities.Status.Defaulted,dateOfCreation:'01 Apr 2017',totalProvisionConsolidated:'2654232146'}
    ,{ccgId:'1',clientId:'456789',fullName:'-',status:Entities.Status.WatchList,dateOfCreation:'01 Apr 2017',totalProvisionConsolidated:'4256841200'}
    ,{ccgId:'1',clientId:'987654',fullName:'Xxxx jjjj',status:Entities.Status.Healthy,dateOfCreation:'01 Apr 2017',totalProvisionConsolidated:'6821464200'}
    ,{ccgId:'1',clientId:'654321',fullName:'Roberto Sanchez',status:Entities.Status.WatchList,dateOfCreation:'02 Apr 2017',totalProvisionConsolidated:'3254682100'}
    ,{ccgId:'1',clientId:'123',fullName:'Jeremy Hill',status:Entities.Status.Defaulted,dateOfCreation:'03 Apr 2017',totalProvisionConsolidated:'2654232146'}
    ];

    getDataForGlobalView(){
        return this.dataForGlobalView;
    }

    addData(groupedData):boolean{

    if (_.findWhere(this.dataForGlobalView, {'ccgId':groupedData.ccgId}) 
        || _.findWhere(this.dataForGlobalView, {'clientId':groupedData.clientId}))    
        return false;
    
    this.dataForGlobalView.push(groupedData);
        return true;
    }

    getAlllDataForCcgId(ccgId:string):Array<Entities.IDataForGlobalView>{
        return _.where(this.dataForGlobalView,{ccgId:ccgId});
    }

setCurrentGroupId(ccgId:string){
    this.currentGroupId=ccgId;
}


getByClientId(clientId:string):Entities.IDataForGlobalView{
    return _.findWhere(this.dataForGlobalView,{clientId:clientId});
}


} 

     