"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var _ = require('underscore');
var commonEntities_1 = require('../entities/commonEntities');
var GroupManagementService = (function () {
    function GroupManagementService() {
        this.currentGroupId = '';
        this.dataForGlobalView = [
            { ccgId: '1', clientId: '123456', fullName: '-', status: commonEntities_1.Entities.Status.Defaulted, dateOfCreation: '01 Apr 2017', totalProvisionConsolidated: '2654232146' },
            { ccgId: '1', clientId: '456789', fullName: '-', status: commonEntities_1.Entities.Status.WatchList, dateOfCreation: '01 Apr 2017', totalProvisionConsolidated: '4256841200' },
            { ccgId: '1', clientId: '987654', fullName: 'Xxxx jjjj', status: commonEntities_1.Entities.Status.Healthy, dateOfCreation: '01 Apr 2017', totalProvisionConsolidated: '6821464200' },
            { ccgId: '1', clientId: '654321', fullName: 'Roberto Sanchez', status: commonEntities_1.Entities.Status.WatchList, dateOfCreation: '02 Apr 2017', totalProvisionConsolidated: '3254682100' },
            { ccgId: '1', clientId: '123', fullName: 'Jeremy Hill', status: commonEntities_1.Entities.Status.Defaulted, dateOfCreation: '03 Apr 2017', totalProvisionConsolidated: '2654232146' }
        ];
    }
    GroupManagementService.prototype.getDataForGlobalView = function () {
        return this.dataForGlobalView;
    };
    GroupManagementService.prototype.addData = function (groupedData) {
        if (_.findWhere(this.dataForGlobalView, { 'ccgId': groupedData.ccgId })
            || _.findWhere(this.dataForGlobalView, { 'clientId': groupedData.clientId }))
            return false;
        this.dataForGlobalView.push(groupedData);
        return true;
    };
    GroupManagementService.prototype.getAlllDataForCcgId = function (ccgId) {
        return _.where(this.dataForGlobalView, { ccgId: ccgId });
    };
    GroupManagementService.prototype.setCurrentGroupId = function (ccgId) {
        this.currentGroupId = ccgId;
    };
    GroupManagementService.prototype.getByClientId = function (clientId) {
        return _.findWhere(this.dataForGlobalView, { clientId: clientId });
    };
    GroupManagementService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], GroupManagementService);
    return GroupManagementService;
}());
exports.GroupManagementService = GroupManagementService;
//# sourceMappingURL=GlobalGroupService.js.map