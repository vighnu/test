import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SearchService {

    private searchString: string='';
    private subject: Subject<string> = new Subject<string>();

    public setSearchString(query: string): void {
        console.log('Search string :'+ query);
        this.searchString = query;
        this.subject.next(query);
    }

    public getSearchString(): Observable<string> {
        return this.subject.asObservable();
    }
}