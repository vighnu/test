import {Component,OnInit} from '@angular/core';
import {SearchService} from '../../services/searchService';

@Component({
    selector:'search-observer',
    template:`
    <p> {{searchString}} </p>
    `
    
})

export class SearchObserver implements OnInit {
        ngOnInit(): void {
            // debugger;
            // this.searchService.getSearchString().subscribe((query)=>{
            //     debugger;
            //     this.searchString=query;
            // });
        }

    public searchString:string;
    
    constructor(private searchService:SearchService){
        this.searchString='';
        debugger;
        this.searchService.getSearchString().subscribe(query=>{
                this.searchString=query;
            });
    }


}