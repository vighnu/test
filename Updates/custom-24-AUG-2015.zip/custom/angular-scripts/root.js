﻿var app = angular.module('remote-server-app', ['ui.router', 'ncy-angular-breadcrumb', 'cgBusy', 'angular-growl', 'oitozero.ngSweetAlert']);//
app.value('cgBusyDefaults', {
    backdrop: true,
    templateUrl: '/template1/custom/js/Vendor/angular-busy/spinner-worm-template.html',
    delay: 100,
    minDuration: 100
});
app.config(function ($stateProvider, $urlRouterProvider, growlProvider) {

    $urlRouterProvider.when("", "/home/dashboard");
    $urlRouterProvider.when("/", "/home/dashboard");
    $urlRouterProvider.when("/home", "/home/dashboard");
    //// For any unmatched url, send to /route1


    $stateProvider
        .state('home', {
            url: '/home',
            template: '<div ui-view> </div>',
            ncyBreadcrumb: {
                label: 'Home'
            },
            resolve: {
                getAllServers: function (apiService) {
                    apiService.getAllServers();
                }
            }
        })
        //.state('home.dashboard', {
        //    url: "/dashboard",
        //    controller: 'dashboardCtrl',
        //    templateUrl: "/template1/custom/angular-scripts/dashboard/template/tmpl.html",
        //    ncyBreadcrumb: {
        //        label: 'Dashboard'
        //    }
        //})

        .state('home.dashboard', {
            url: "/dashboard",
            views: {
                '': {
                    controller: 'dashboardCtrl',
                    templateUrl: "/template1/custom/angular-scripts/dashboard/template/dashboardMain.html"
                },
                'totalSubscriptions@home.dashboard': {
                    controller: 'totalSubscriptionsCtrl',
                    templateUrl:"/template1/custom/angular-scripts/dashboard/template/totalSubscriptions.html"
                },
                'widgets@home.dashboard': {
                    controller: '',
                    templateUrl: "/template1/custom/angular-scripts/dashboard/template/widgets.html"
                }
            },
            ncyBreadcrumb: {
                label: 'Dashboard'
            }
        })


        .state('home.servers', {
            url: "/servers",
            templateUrl: "/template1/custom/angular-scripts/servers/template/allServers.html",
            controller: 'serversCtrl',
            ncyBreadcrumb: {
                label: 'My Servers'
            }
        })
        .state('home.servers.add', {
            url: "/Add",
            templateUrl: "/template1/custom/angular-scripts/servers/template/addNewServer.html",
            controller: 'addNewServerCtrl',
            ncyBreadcrumb: {
                label: 'Add'
            }
        })
        .state('home.servers.view', {
            url: "/:id",
            templateUrl: "/template1/custom/angular-scripts/servers/template/viewServer.html",
            controller: 'viewServerCtrl',
            ncyBreadcrumb: {
                label: '{{server.name}}'
            }
        })
        .state('home.servers.view.serverDetails', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/serverDetails.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.performance', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/performance.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.services', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/services.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.processes', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/processes.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.users', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/users.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.events', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/events.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        })
        .state('home.servers.view.logs', {
            url: "/:id",
            templateUrl: '/template1/custom/angular-scripts/servers/template/logs.html',
            controller: '',
            ncyBreadcrumb: {
                skip: true // Never display this state in breadcrumb.
            }
        });
    $urlRouterProvider.otherwise("/home/dashboard");
    growlProvider.globalTimeToLive({ success: 2000, error: 5000, warning: 3000, info: 10000 });
});

/*
 .state('list.viewList', {
             url: '/:listId',
             controller: 'listDetailsCtrl',
             templateUrl: '/Admin/mws/HTML/js/custom/directives/admin-list/templates/admin-list-details.html',
             ncyBreadcrumb: {
                 label: '{{list.Name}}'
             },
             cache: false //required
         })
*/
//Code to go from one list to another
//$state.transitionTo('list.mail');