﻿/// <reference path="../template/tmpl1.html" />
app.directive('totalSubscriptionWidget', function (iconServices) {
    return {
        restrict: 'A',
        replace: 'true',
        scope: {
            totalservers: '@',
            totalservices: '@',
            totallogs: '@',
            totalevents: '@'

        },
        templateUrl: '/template1/custom/angular-scripts/total-subscriptions-widget/template/tmpl.html',
        link: function (scope, element, attr, cntrl) {
            scope.types = types;
            scope.getClass = function (type) {
                return iconServices.getClass(type);
            };
        }
    };
});