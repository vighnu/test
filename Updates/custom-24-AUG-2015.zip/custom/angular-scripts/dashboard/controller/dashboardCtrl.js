﻿app.controller('dashboardCtrl', function ($scope, $rootScope, $state, $log, utilityServices, controllerInitServices) {
    $scope = controllerInitServices.init($scope);
    $scope.thePromise = controllerInitServices.waitTillValueIsLoaded($rootScope, $scope, 'servers', 'servers');
    $scope.thePromise.then(function () {
        $scope.totalservers = $scope.servers.length;
        $log.info('Loaded and server is : ' + $scope.totalservers);
    });



    //$scope.totalservers = '0';
    //$log.info('Loaded and server is : ' + $scope.totalservers);
    //$scope.$on('initComplete', function (event, data) {
    //    $scope.totalservers = $rootScope.servers.length;
    //});
    //$scope.$on('initFailed', function (event, data) {
    //    $scope.totalservers = 'Error';
    //});
    //if (utilityServices.IsNullOrUndefined($rootScope.servers)) {

    //} else {
    //    $scope.totalservers = $rootScope.servers.length;
    //}
});
