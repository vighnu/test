﻿app.controller('totalSubscriptionsCtrl', function ($scope, $rootScope, $state, $log, utilityServices, controllerInitServices) {
    $scope = controllerInitServices.init($scope);
    $scope.thePromise = controllerInitServices.waitTillValueIsLoaded($rootScope, $scope, 'servers');
    $scope.thePromise.then(function () {
        $scope.totalServers = $scope.servers.length;
    });
    $scope.totalServers = '0';
    $scope.totalServices = '0';
    $scope.totalLogs = '0';
    $scope.totalEvents = '0';
});