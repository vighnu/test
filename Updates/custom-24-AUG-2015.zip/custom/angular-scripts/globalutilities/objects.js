﻿function Server() {
    this.name = '';
    this.username = '';
    this.password = '';
    this.friendlyName = '';
    this.description = '';
}

function Response() {
    this.isSuccessfull = false;
    this.data = null;
    this.message = '';

}
var types = {
    Servers: "Servers",
    Server: 'Server',
    WindowsServices: 'WindowsServices',
    WindowsService: 'WindowsService',
    Processes: 'Processes',
    Process: 'Process',
    Cpu: 'Cpu',
    Ram: 'Ram',
    Events: 'Events',
    Event: 'Event',
    HardDiscs: 'HardDiscs',
    HardDisc: 'HardDisc',
    Logs: 'Logs',
    Log: ''


};