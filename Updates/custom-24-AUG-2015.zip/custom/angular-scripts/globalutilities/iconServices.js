﻿app.service('iconServices', function () {

    var getIcon = function (type) {
        var iconClass = '';
        switch (type) {
            case types.Servers:
                iconClass = 'fa fa-th-large';
                break;
            case types.Server:
                iconClass = 'fa fa-windows';
                break;
            case types.WindowsServices:
                iconClass = 'fa fa-cogs';
                break;
            case types.WindowsService:
                break;
            case types.Processes:
                break;
            case types.Process:
                break;
            case types.Cpu:
                break;
            case types.Ram:
                break;
            case types.HardDiscs:
                break;
            case types.HardDisc:
                break;
            case types.Logs:
                iconClass = 'fa fa-files-o';
                break;
            case types.Log:
                break;
            case types.Events:
                iconClass = 'fa fa-bolt';
                break;
                case types.Event:
                    break;
            default:
                break;
        }
        return iconClass;
    };

    this.getClass = function (type) {
        return getIcon(type);
    };
});





var globalConstants = {
    types: types
}