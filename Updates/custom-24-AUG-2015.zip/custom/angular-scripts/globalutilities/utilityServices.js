﻿app.service('utilityServices', function () {
    var getBaseUrl = function () {
        /// <summary>
        /// returned url will be http://www.vedaholistic.in/
        /// Please note the url will always end with a '/'
        /// </summary>
        return location.protocol + "//" + location.hostname +
                 (location.port && ":" + location.port) + "/";

    };

    this.getAdminBaseUrl = function () {
        /// <summary>
        /// This will return to the calling function the base address of the Admin api
        /// The url will always end with a '/'
        /// </summary>
        /// <returns type="">eg : http://www.vedaholistic.in/Admin/ </returns>
        var baseUrl = getBaseUrl();
        return baseUrl + "Admin/";
    };

    this.IsNullOrUndefined = function (item) {
        var isNull = false;
        if (_.isUndefined(item) || _.isNull(item)) {
            isNull = true;
        }
        return isNull;
    };

    this.IsEmpty = function (value) {
        return value.trim().length === 0;
    };

    this.getTodaysDate = function (format) {
        var requiredDate = "";
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        var seperator = "-";
        switch (format) {
            case "dd-MM-yyyy":
                {
                    seperator = "-";
                    requiredDate = dd + seperator + mm + seperator + yyyy;
                }
                break;
            case "dd/MM/yyyy":
                {
                    seperator = "/";
                    requiredDate = dd + seperator + mm + seperator + yyyy;
                }
                break;

            default:
                seperator = "-";
                requiredDate = dd + seperator + mm + seperator + yyyy;
                break;
        }


        return requiredDate;
    };

    this.getJustStringFromHtml = function (html) {

        return String(html).replace(/<[^>]+>/gm, '');

    };

    this.addHours = function (date, hours) {
        var d = new Date(date);
        d.addHours(hours);
        return d;
    };

});