﻿app.service('controllerInitServices', function (iconServices, utilityServices, $state, $rootScope, $q, $interval) {
    this.init = function ($scope) {
        $scope.$state = $state;
        $scope.types = types;
        $scope.thePromise = $rootScope.theInitPromise;
        $scope.getClass = function (type) {
            if (utilityServices.IsNullOrUndefined(type)) {
                return '';
            }
            return iconServices.getClass(type);
        };
        return $scope;
    }

    this.waitTillValueIsLoaded = function (fromObject, toObject, propertyNameOfFromObject, propertyNameOfToObject) {

        var promise;
        var stopTimer = function () {
            if (angular.isDefined(promise)) {
                $interval.cancel(promise);
                promise = undefined;
            }
        };

        var deferred = $q.defer();
        if (angular.isDefined(promise)) {
            deferred.resolve(true);
        }

        promise = $interval(function () {
            //first check if the items has the property
            if (_.has(fromObject, propertyNameOfFromObject)) {
                //stop it simple
                var propertyNameToSetInToObject = '';
                if (utilityServices.IsNullOrUndefined(propertyNameOfToObject) || utilityServices.IsEmpty(propertyNameOfToObject)) {
                    propertyNameToSetInToObject = propertyNameOfFromObject;
                } else {
                    propertyNameToSetInToObject = propertyNameOfToObject;
                }

                toObject[propertyNameToSetInToObject] = _.property(propertyNameOfFromObject)(fromObject);
                stopTimer();
                deferred.resolve(true);
            }
        }, 100);
        return deferred.promise;
    };


});

/*
app.factory('commonControllerService', function (iconServices, utilityServices, $state, $rootScope) {

    var factory = {};

    factory.init = function ($scope) {
        $scope.$state = $state;
        $scope.types = types;
        $scope.thePromise = $rootScope.theInitPromise;
        $scope.getClass = function (type) {
            if (utilityServices.IsNullOrUndefined(type)) {
                return '';
            }
            console.log('Passed type is : ' + type);
            return iconServices.getClass(type);
        };
        return $scope;
    }
    return factory;
});
*/