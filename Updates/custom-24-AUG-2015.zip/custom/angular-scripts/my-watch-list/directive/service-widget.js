﻿app.directive('serviceWidget', function () {
    return {
        restrict: 'A',
        templateUrl: '/template1/custom/angular-scripts/my-watch-list/template/widget1.html',
        link: function (scope, element, attr) {

            scope.onHover = false;

        }
    };
});