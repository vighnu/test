﻿app.directive('myServiceWatcher', function () {
    return {
        restrict: 'A',
        templateUrl: '/template1/custom/angular-scripts/my-watch-list/template/tmpl.html',
        link: function (scope, element, attr) {

        }
    };
});