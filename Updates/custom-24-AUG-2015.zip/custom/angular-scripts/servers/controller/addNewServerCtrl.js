﻿app.controller('addNewServerCtrl', function ($scope, $rootScope, $state, $log, utilityServices, serverServices, controllerInitServices) {

    $scope = controllerInitServices.init($scope);
    $scope.server = new Server();
    $scope.isServerNameUnique = null;
    $scope.serverNameClass = '';


    $scope.$on('initComplete', function (event, data) {
        $scope.servers = $rootScope.servers;
    });
    $scope.$on('initFailed', function (event, data) {
    });
    $scope.submit = function () {
        serverServices.addNewServer($scope.server).then(function(result) {
            if (result) {
                $state.transitionTo('home.servers');
            }
        });
        $log.info($scope.server);
    };

    $scope.checkServerName = function () {
        //check the servername in the rootScope or somewhere.
        if (!utilityServices.IsNullOrUndefined($scope.server.name) && !utilityServices.IsEmpty($scope.server.name)) {
            var server = _.findWhere($rootScope.servers, { name: $scope.server.name.toLowerCase() });
            if (utilityServices.IsNullOrUndefined(server)) {
                //we are good to go
                $scope.isServerNameUnique = true;
            } else {
                $scope.isServerNameUnique = false;
            }
        } else {
            $scope.isServerNameUnique = null;
        }
    }

    $scope.getClassToShowServerNameValidity = function () {
        
        if (utilityServices.IsNullOrUndefined($scope.server.name) || utilityServices.IsEmpty($scope.server.name)) {
            $scope.serverNameClass = '';
        } else {
            if (($scope.form.serverName.$invalid && !$scope.form.serverName.$pristine)) {
                $scope.serverNameClass = 'has-error';
            }
            else if (!$scope.isServerNameUnique) {
                $scope.serverNameClass = 'has-error';
            } else if ($scope.isServerNameUnique) {
                $scope.serverNameClass = 'has-success';
            } else {
                $scope.serverNameClass = '';
            }
        }

        //if (($scope.form.serverName.$invalid && !$scope.form.serverName.$pristine) || !$scope.isServerNameUnique) {
        //    $scope.serverNameClass = 'has-error';
        //} else if ($scope.isServerNameUnique) {
        //    $scope.serverNameClass = 'has-success';
        //} else {
        //    $scope.serverNameClass = '';
        //}
        return $scope.serverNameClass;
    };

    $scope.clearAll = function () {
        $scope.server = new Server();
    };
});