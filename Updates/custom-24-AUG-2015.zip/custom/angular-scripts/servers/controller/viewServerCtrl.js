﻿app.controller('viewServerCtrl', function ($scope, $rootScope, $state, $log, utilityServices, serverServices, $stateParams, $log, controllerInitServices) {
    $scope.id = $stateParams.id;
    $log.info($scope.id);

    $scope = controllerInitServices.init($rootScope, $scope, $state);
    $scope.server = {};
    $scope.$on('initComplete', function (event, data) {
        $scope.server = {};
        $scope.server.name = 'Test';
    });
    $scope.$on('initFailed', function (event, data) {
    });
    $scope.server.name = 'Test';
    $scope.selected = 'serverDetails';
    $scope.showServerDetails = function () {
        //get the server details via promises. Show loading icon. Once done, show the item.
    };
    $state.transitionTo('home.servers.view.serverDetails');
});