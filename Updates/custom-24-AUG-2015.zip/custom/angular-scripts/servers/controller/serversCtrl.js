﻿app.controller('serversCtrl', function ($scope, $state, $rootScope, $log, $q, controllerInitServices) {
    $scope = controllerInitServices.init($rootScope, $scope, $state);
    $scope.servers = $rootScope.servers;
    $scope.$on('initComplete', function (event, data) {
        $scope.servers = $rootScope.servers;
    });
    $scope.$on('initFailed', function (event, data) {
    });

    $scope.addNewServer = function () {
        $state.transitionTo('home.servers.add');
    };
});

/* CG Promise
 $scope.thePromise = listServices.getAll();
        $scope.thePromise.then(function (data) {
            lists = data;
            $scope.totalLists = lists.length;
            $scope.gotData = true;
            $scope.tableParams.reload();
        });
*/