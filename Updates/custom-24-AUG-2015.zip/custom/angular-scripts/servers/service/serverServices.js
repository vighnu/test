﻿app.service('serverServices', function (apiService, $q, growl) {
    this.addNewServer = function (server) {
        var deferred = $q.defer();
        //the below will be another promise
        apiService.addNewServer(server).then(function (response) {
            //response will be an object
            if (response.isSuccessfull) {
                growl.success(response.message);
                //show a message
            } else {
                growl.error(response.message);
            }
            deferred.resolve(response.isSuccessfull);
        });
        return deferred.promise;
    };
});

/* What happens when a new server is added
1-Api gets a json response from .net
2-Api sees if it is successful
 a)-Adds server to the collection
 b)updates $rootScope
 c)sends data back to calling service (here being serverService) 
    Data that is sent back will be 
    i)The Server
    ii)Is Successfull or not
    iii)Message to display on the popup
3-ServerService just displays the popup and the controller, transitions state to allServers page.

*/