﻿/// <reference path="my-servers.js" />
app.directive('myServers',function() {
    return {
        restrict: 'A',
        templateUrl: '/template1/custom/angular-scripts/servers/template/my-servers-dir.html',
        link: function(scope, element, attr) {

        }
    };
})