﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sixeyed.Extensions.Samples.Demo3
{
    public class ReferenceDataItem
    {
        public string Code { get; set; }

        public string Description { get; set; }
    }
}
