﻿
namespace Sixeyed.ExtensionLibrary
{
    public static class ICommunicationObjectExtensions
    {
    }
}
