﻿
namespace System.Net.Http
{
    public static class HttpResponseMessageExtensions
    {
    }
}
