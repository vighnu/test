﻿using System.ComponentModel;
using System.Linq;

namespace System
{
    public static class EnumExtensions
    {
    }
}
