﻿using System.Reflection;

namespace System.Linq.Expressions
{
    public static class LambdaExpressionExtensions
    {
    }
}