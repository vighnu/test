﻿
namespace Sixeyed.ExtensionLibrary.Domain.Model
{
    public static class DbContextExtensions
    {  
    }
}
