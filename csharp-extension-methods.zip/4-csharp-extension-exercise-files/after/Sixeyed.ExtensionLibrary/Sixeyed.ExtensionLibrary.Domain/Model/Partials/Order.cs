﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sixeyed.ExtensionLibrary.Domain.Model
{
    public partial class Order : IAudited
    {
    }
}
