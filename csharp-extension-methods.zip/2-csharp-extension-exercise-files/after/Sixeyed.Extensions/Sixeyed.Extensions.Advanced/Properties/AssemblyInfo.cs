﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Sixeyed.Extensions.Advanced")]
[assembly: AssemblyProduct("Sixeyed.Extensions.Advanced")]

[assembly: InternalsVisibleTo("Sixeyed.Extensions.Advanced.Tests")]

[assembly: ComVisible(false)]
[assembly: Guid("d0788876-badf-4b2f-bf80-adba5773de78")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
