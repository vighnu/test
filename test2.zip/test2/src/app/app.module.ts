import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { Test2ComponentComponent } from './test2-component/test2-component.component';

import {AngularFireModule} from 'angularfire2';
import {AngularFireDatabaseModule} from 'angularfire2/database';




var config = {
  apiKey: "AIzaSyB4ggZnsgKynnyxPmNJYDGivgO95UpfCc0",
  authDomain: "central-trade-repo.firebaseapp.com",
  databaseURL: "https://central-trade-repo.firebaseio.com",
  projectId: "central-trade-repo",
  storageBucket: "central-trade-repo.appspot.com",
  messagingSenderId: "753302091826"
};


@NgModule({
  declarations: [
    AppComponent,
    Test2ComponentComponent
  ],
  imports: [
    BrowserModule,
        AngularFireModule.initializeApp(config),
        AngularFireDatabaseModule,
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
