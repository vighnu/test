import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-test2-component',
  templateUrl: './test2-component.component.html',
  styleUrls: ['./test2-component.component.css']
})

export class Test2ComponentComponent implements OnInit {
  items: AngularFireList<number[]>;
  fxoValue: number;
  lpValue: number;
  hniValue: number;



  constructor(
    private db: AngularFireDatabase
  ) { }

  getLP() {
    //const https://console.firebase.google.com/LP = '/LP';
    //this.value = this.db.object(https://console.firebase.google.com/LP)
    this.items = this.db.list("/");

  }

  ngOnInit() {
    this.items = this.db.list("/");
    this.items.snapshotChanges().subscribe(
      (snapshot: any) => snapshot.forEach(element => {
        if (element.key === "FXO") {
          this.fxoValue = element.payload.val();
        }
        else if (element.key === "LP") {
          this.lpValue = element.payload.val();
        }
        else {
          this.hniValue = element.payload.val();
        }
      }
      )


    );

  }

}
