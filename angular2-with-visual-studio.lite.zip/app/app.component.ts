﻿import { Component } from 'angular2/core';
import { HomeComponent } from './home-component/home-component'
@Component({
    selector: 'my-app',
    template: `
<home-component></home-component>
<div class="container"> 
    <h1>My First Angular 2 App.</h1>
</div>`,
    directives: [HomeComponent]
})
export class AppComponent { }
