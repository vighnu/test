﻿import { Component } from 'angular2/core';

@Component({
    selector: 'home-component',
    templateUrl: 'app/home-component/home-component.html'
})

export class HomeComponent {

}