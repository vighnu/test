﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using FoApps.Common;

namespace Fo1
{
    class Program
    {
        static void Main(string[] args)
        {
            var simulator = new Simulator();

            Task.Run(() => simulator.Simulate(new FoApps.Common.Fo1())).Wait();
        }

        private static async Task RunTask()
        {
            await Task.Run(() => new Simulator().Simulate(new FoApps.Common.Fo1()));
        }
    }
}