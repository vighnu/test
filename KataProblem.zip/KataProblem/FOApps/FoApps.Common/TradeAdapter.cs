﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FoApps.Common
{
    public interface ITradeAdapter
    {
        TradeRequest Adapt();
    }

    public class Fo1TradeAdapter : ITradeAdapter
    {
        private const string AppName = "Fo1";

        public TradeRequest Adapt()
        {
            return AdapterSimualator.Simulate(AppName);
        }
    }

    public class Fo2TradeAdapter : ITradeAdapter
    {
        private const string AppName = "Fo2";

        public TradeRequest Adapt()
        {
            return AdapterSimualator.Simulate(AppName);
        }
    }

    public class Fo3TradeAdapter : ITradeAdapter
    {
        private const string AppName = "Fo3";

        public TradeRequest Adapt()
        {
            var tradeRequest1 = AdapterSimualator.Simulate(AppName);
            var tradeRequest2 = AdapterSimualator.Simulate(AppName);
            return new TradeRequest()
            {
                Trades =  tradeRequest1.Trades.Union(tradeRequest2.Trades).ToList(),
                Context = tradeRequest1.Context
            };
        }
    }

    public class AdapterSimualator
    {
        public static TradeRequest Simulate(string appName)
        {
            return SimulateAnAdaptOperation(appName);
        }

        private static  TradeRequest SimulateAnAdaptOperation(string appName)
        {
            return new TradeRequest()
            {
                Trades = new List<Trade>()
             {
                 new Trade()
                 {
                     Product = new Product()
                     {
                         ProductStructure = "OPT",
                         Sgway = "Both",
                         TypObj = "FX"
                     },
                     TradeDetails = new TradeDetails()
                     {
                         TradeSpecificValue = @"<synthetic user=""xyz.rasd"" monitoringStructure=""1123548"" bookingArea=""PARIS"" bookingApplication=""XAEF"" >

                         <instrument way=""add"" id=""IRSIForceElement"" name=""PDC_1"" maturity=""5.00277777777777777777777"" >
                         <startDate>2017-04-04 </startDate>
                         <endDate>2017-12-31</endDate>
                         <currentDate>2017-11-19 </currentDate>
                         <rate>60.051</rate>
                         <totalValue> 500 </totalValue>
                         <buyCurrency> INR</buyCurrency>
                         <sellCurrency> USD</sellCurrency>


                         </instrument>


                         </synthetic>"
                     },
                     SpecificFields = new List<Specific>()
                     {
                         new Specific(){Name = "TradeId",Value = "Xyz.Hgk"},
                         new Specific(){Name = "Trader_Physial_Location",Value = "Xyz.Hgk"},
                         new Specific(){Name = "Trader_Contract_Location",Value = "Xyz.Hgk"},
                         new Specific(){Name = "SettlementType",Value = "Xyz.Hgk"},
                         new Specific(){Name = "Cleared",Value = "Xyz.Hgk"},
                         new Specific(){Name = "ClearingPartyType",Value = "Xyz.Hgk"},
                         new Specific(){Name = "FxRate",Value = "Xyz.Hgk"},
                     }
                 }
             },
                Context = new Context()
                {
                    Action = "TradeSync",
                    ApplicationName = appName,
                    Medium = "Voice",
                    SessionId = "125687-54123-4512356",
                    RequestId = "1235467845126",
                    TimeStamp = DateTime.UtcNow.AddMinutes(-50),
                    Server = "zyx.host.socgen.com"
                }
            };
        }
    }

    [Serializable]
    public class TradeRequest
    {
        public TradeRequest()
        {
            Trades = new List<Trade>();
        }

        public List<Trade> Trades { get; set; }

        public Context Context { get; set; }
    }

    [Serializable]
    public class Trade
    {
        public Trade()
        {
            SpecificFields = new List<Specific>();
        }

        public List<Specific> SpecificFields { get; set; }

        public Product Product { get; set; }

        public TradeDetails TradeDetails { get; set; }
    }

    [Serializable]
    public class Context
    {
        public string Action { get; set; }

        public string ApplicationName { get; set; }

        public string SessionId { get; set; }

        public string Server { get; set; }

        public string RequestId { get; set; }

        public DateTime TimeStamp { get; set; }

        public string Medium { get; set; }

    }

    [Serializable]
    public class Product
    {
        public string ProductStructure { get; set; }

        public string TypObj { get; set; }

        public string Sgway { get; set; }
    }

    [Serializable]
    public class TradeDetails
    {
        public string TradeSpecificValue { get; set; }
    }

    [Serializable]
    public class Specific
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}