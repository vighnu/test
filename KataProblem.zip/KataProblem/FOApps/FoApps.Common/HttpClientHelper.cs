﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;
namespace FoApps.Common
{
    public class HttpClientHelper
    {
        public static async Task PostData(string url, TradeRequest data)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);


                //var serializedData = JsonConvert.SerializeObject(data);

                //StringContent content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

                //var formContent = new FormUrlEncodedContent(new[]
                //{
                //    new KeyValuePair<string, string>("request", JsonConvert.SerializeObject(data)),
                //});

                var result = await client.PostAsJsonAsync(url, data);
                result.EnsureSuccessStatusCode();
                string resultContent = await result.Content.ReadAsStringAsync();
                Console.WriteLine(resultContent);
            }
        }
    }
}