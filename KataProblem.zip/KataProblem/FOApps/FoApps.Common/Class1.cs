﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace FoApps.Common
{
    public interface IApp
    {
        string AppName { get; set; }

        string RequestFileName { get; set; }

        string RequestFormat { get; set; }

        ITradeAdapter Adapter { get; }

        string PostUrl { get; set; }

    }

    public abstract class AppBase : IApp
    {
        protected AppBase(string appName, string requestFileName, string requestFormat, string postUrl)
        {
            AppName = appName;
            RequestFileName = requestFileName;
            RequestFormat = requestFormat;
            PostUrl = postUrl;
        }

        public string AppName { get; set; }
        public string RequestFileName { get; set; }
        public string RequestFormat { get; set; }

        public ITradeAdapter Adapter => GetAdapter();
        public string PostUrl { get; set; }

        protected abstract ITradeAdapter GetAdapter();

    }

    public class Fo1 : AppBase
    {


        public Fo1() : base("Fo1", "Fo1.request.xml", "xml", "http://localhost:8989/LoadBalancer/api/v1/trades/pushTrade")
        {

        }


        protected override ITradeAdapter GetAdapter()
        {
            return new Fo1TradeAdapter();
        }
    }

    public class Fo2 : AppBase
    {
        public Fo2() : base("Fo2", "Fo2.request.json", "json", "http://localhost:8989/LoadBalancer/api/v1/trades/pushTrade")
        {

        }

        protected override ITradeAdapter GetAdapter()
        {
            return new Fo2TradeAdapter();
        }

    }

    public class Simulator
    {
        public async Task Simulate(IApp app)
        {
            Console.WriteLine($"Front Office App {app.AppName} is starting");

            Console.WriteLine($"{app.AppName} Request Format : ");
            var request = File.ReadAllText(Path.Combine("Requests", $"{app.RequestFileName}"));

            Console.WriteLine(request);

            Console.WriteLine("Enter the number of  simulations to perform");

            int numberOfSimulations;
            if (!int.TryParse(Console.ReadLine(), out numberOfSimulations))
            {
                Console.WriteLine("Invalid number entered. Please try again.");
            }
            else
            {
                Console.WriteLine("Begining Simulations");

                var adapter = app.Adapter;

                try
                {
                    for (int i = 0; i < numberOfSimulations; i++)
                    {
                        Console.WriteLine($"Simulating Trade No :  {i}");
                        await Task.Delay(50);
                        Console.WriteLine($"Trade has been performed.");
                        Console.WriteLine("Logging to data base with custom format.");
                        await Task.Delay(50);
                        Console.WriteLine("Logging to internal database is completed.");

                        Console.WriteLine("Getting Creating CTR Protocol");
                        var obj = adapter.Adapt();
                        Console.WriteLine("Created CTR protocol.");
                        Console.WriteLine(SerializeObject(obj));
                        Console.WriteLine("Pushing Data to Central Trade Repository.");

                        await HttpClientHelper.PostData(app.PostUrl, obj);

                        Console.WriteLine("Pushing Data to Central Trade Repository completed.");

                        Console.WriteLine("--------------------------------------------");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }

        private static string SerializeObject<T>(T toSerialize)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(toSerialize.GetType());

            using (StringWriter textWriter = new StringWriter())
            {
                xmlSerializer.Serialize(textWriter, toSerialize);
                return textWriter.ToString();
            }
        }

    }




}
