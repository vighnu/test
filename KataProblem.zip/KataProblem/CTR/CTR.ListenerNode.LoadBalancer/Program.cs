﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using CTR.Shared.Servers;
using Microsoft.Owin.Hosting;
using Owin;

namespace CTR.ListenerNode.LoadBalancer
{
    class Program
    {
        static void Main(string[] args)
        {
            var url = ConfigurationManager.AppSettings["url"];
            Console.WriteLine($"Starting Server at {url}");
            using (TestServer.Start(url))
            {
                Console.WriteLine("Service has started");
                Console.ReadLine();
            }
        }
    }
}
