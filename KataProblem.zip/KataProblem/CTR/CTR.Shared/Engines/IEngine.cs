﻿using System.Collections.Generic;
using CTR.Shared.Validations;
using FoApps.Common;
using Unity.Lifetime;

namespace CTR.Shared.Engines
{
    public interface IEngine
    {
        void Init();
    }

    public static class Engines
    {
        static Engines()
        {

        }

        public static void Start()
        {
            //This is where all the engines are loaded and added to the unity container.
            UnityDI.Container.RegisterType(typeof(IEngine), typeof(ValidationEngine), "ValidationEngine",
                new ContainerControlledLifetimeManager());

            UnityDI.Container.RegisterType(typeof(IEngine), typeof(AuditEngine), "AuditEngine",
                new ContainerControlledLifetimeManager());

        }

    }

    public class ValidationEngine : IEngine
    {
        public void Init()
        {
            //this is where we load all the various validations and add them to unity
            _productValidations = new Dictionary<string, List<IValidations>>();
        }



        private Dictionary<string, List<IValidations>> _productValidations;


    }

    public class FxOValidations : IValidations
    {
        public bool Validate(TradeRequest request)
        {
            throw new System.NotImplementedException();
        }
    }


    public class AuditEngine : IEngine
    {
        public void Init()
        {
            throw new System.NotImplementedException();
        }
    }
}