﻿using System;
using System.Web.Http;
using Microsoft.Owin.Hosting;
using Owin;
using Unity.WebApi;

namespace CTR.Shared.Servers
{
    public class TestServer
    {
        public static IDisposable Start(string url)
        {
            return WebApp.Start<OwinConfiguration>(url);
        }
    }

    public class WebApiConfig
    {
        public static HttpConfiguration Register()
        {
            var config = new HttpConfiguration();
            config.DependencyResolver = new UnityDependencyResolver(UnityDI.Container);

            config.MapHttpAttributeRoutes();

            return config;
        }
    }

    public class OwinConfiguration
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseWebApi(WebApiConfig.Register());

        }
    }
}