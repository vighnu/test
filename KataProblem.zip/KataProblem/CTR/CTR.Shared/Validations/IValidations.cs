﻿using FoApps.Common;

namespace CTR.Shared.Validations
{
    public interface IValidations
    {
        bool Validate(TradeRequest request);
    }
}