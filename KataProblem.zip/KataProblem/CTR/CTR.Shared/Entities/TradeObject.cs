﻿using System;
using System.Collections.Generic;
using FoApps.Common;

namespace CTR.Shared.Entities
{
    public class TradeObject
    {
        private readonly TradeRequest _originalRequest;

        public TradeObject(TradeRequest originalRequest)
        {
            _originalRequest = originalRequest;
        }



    }

    //[Serializable]
    //public class Trade
    //{
    //    public Trade()
    //    {
    //        SpecificFields = new List<FoApps.Common.Specific>();
    //    }

    //    public List<FoApps.Common.Specific> SpecificFields { get; set; }

    //    public FoApps.Common.Product Product { get; set; }

    //    public FoApps.Common.TradeDetails TradeDetails { get; set; }
    //}

    //[Serializable]
    //public class ContextObject
    //{
    //    public string Action { get; set; }

    //    public string ApplicationName { get; set; }

    //    public string SessionId { get; set; }

    //    public string Server { get; set; }

    //    public string RequestId { get; set; }

    //    public DateTime TimeStamp { get; set; }

    //    public string Medium { get; set; }

    //}

    //[Serializable]
    //public class ProductObject
    //{
    //    public string ProductStructure { get; set; }

    //    public string TypObj { get; set; }

    //    public string Sgway { get; set; }
    //}

    //[Serializable]
    //public class TradeDetailsObject
    //{
    //    public string TradeSpecificValue { get; set; }
    //}

    //[Serializable]
    //public class SpecificObject
    //{
    //    public string Name { get; set; }

    //    public string Value { get; set; }
    //}

}