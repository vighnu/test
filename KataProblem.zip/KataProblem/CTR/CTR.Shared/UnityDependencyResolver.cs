﻿using System;
using Unity;

namespace CTR.Shared
{
    public static class UnityDI
    {

        static UnityDI()
        {
            Container = new UnityContainer();
            AutoPopulateFromConfigAndAttributed();
        }

        public static IUnityContainer Container { get; set; }

        private static void AutoPopulateFromConfigAndAttributed()
        {
            Console.WriteLine("Unity will automatically create registrations from config as well as Attributed Types.");
            Console.WriteLine("TODO::");
        }
    }
}