﻿using System.Web.Http;
using FoApps.Common;

namespace CTR.Shared.Controllers
{
    [RoutePrefix("api/v1/trades")]
    public class TradesController : ApiController
    {

        [Route("")]
        [HttpGet]
        public IHttpActionResult Get()
        {
            return Ok("Works");
        }

        [Route("pushTrade")]
        [HttpPost]
        public IHttpActionResult PushTrade([FromBody] TradeRequest request)
        {

            if (request == null)
                return BadRequest();




            //Log incoming Request
            //Kick start the validation engine
            //Push trade to Computation Queue
            
            return Ok();
        }
    }
}