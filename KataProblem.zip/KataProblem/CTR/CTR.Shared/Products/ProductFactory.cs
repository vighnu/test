﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using CTR.Shared.Entities;
using FoApps.Common;

namespace CTR.Shared.Products
{
    public class ProductFactory
    {
        private readonly Dictionary<string, Type> _products;

        public ProductFactory()
        {
            _products = new Dictionary<string, Type>();
            PopulateProductsDictionary();
        }

        private void PopulateProductsDictionary()
        {
            Console.WriteLine("Using Unity and reflection, products are populated by their name.");
            Console.WriteLine("The same can also be populated using unity Config and does not involve reflection.");
            Console.WriteLine("This is done only once during the start of the application");
            _products.Add("OPT_FX", typeof(FxOptions));
            _products.Add("PL_LP", typeof(FxOptions));

        }


        public IProduct CreateProduct(Trade trade)
        {
            var key = trade.Product.ProductStructure.ToUpper() + "_" + trade.Product.TypObj.ToUpper();
            Console.WriteLine("Key is : " + key);

            if (_products.ContainsKey(key))
            {
                Console.WriteLine("Product was found in the Products Dictionary. Creating a new instance of the product.");
                var type = _products[key];
                var instance = (IProduct)Activator.CreateInstance(type, trade);
                return instance;
            }

            Console.WriteLine("Product cannot be found.");
            return null;
        }
    }

    public interface IProduct
    {
        string ProductStructure { get; set; }
        string TypObj { get; set; }
        string SgWay { get; }
    }

    public abstract class ProductBase : IProduct
    {
        protected ProductBase(string productStructure, string typObj, string sgWay)
        {
            ProductStructure = productStructure;
            TypObj = typObj;
            SgWay = sgWay;
        }

        public string ProductStructure { get; set; }
        public string TypObj { get; set; }
        public string SgWay { get; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime CurrentDate { get; set; }

    }

    public class FxOptions : ProductBase
    {
        public FxOptions(Trade trade) : base(trade.Product.ProductStructure, trade.Product.TypObj, trade.Product.Sgway)
        {
            ConvertAndSetPropertiesFromDealDetails(trade);
        }

        private void ConvertAndSetPropertiesFromDealDetails(Trade trade)
        {
            Console.WriteLine("Converts and sets various FxOption Properties from the Trade Details");
        }

        public string Way { get; set; }
        public decimal Rate { get; set; }
        public decimal TotalValue { get; set; }
        public string BuyCurrency { get; set; }
        public string SellCurrency { get; set; }
    }

    public class LoanProducts : ProductBase
    {
        public LoanProducts(Trade trade) : base(trade.Product.ProductStructure, trade.Product.TypObj, trade.Product.Sgway)
        {
            ConvertAndSetPropertiesFromDealDetails(trade);
        }

        private void ConvertAndSetPropertiesFromDealDetails(Trade trade)
        {
            Console.WriteLine("Converts and sets various FxOption Properties from the Trade Details");
        }

        public string TraderId { get; set; }

        public decimal PropertyX { get; set; }
        public decimal PropertyY { get; set; }
        public decimal PropertyZ { get; set; }
        public string TraderPhysialLocation { get; set; }
        public string TraderContractLocation { get; set; }
    }
}