import {NgModule} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CreateNewFicheComponent } from "./components/CreateNewFicheComponent/CreateNewFicheComponent";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
// import ng2-bootstrap alerts module
 
import { Ng2BootstrapModule } from 'ngx-bootstrap/ng2-bootstrap';
// import { AlertModule } from 'node_modules/ngx-bootstrap/alert/';
import { AlertModule } from 'ngx-bootstrap/ng2-bootstrap';
import { ModalModule } from 'ngx-bootstrap/ng2-bootstrap';
import {GroupManagementService} from './services/GlobalGroupService' 

@NgModule({
    imports:[BrowserModule,NgbModule.forRoot()
    ,Ng2BootstrapModule
    ,AlertModule.forRoot()
    ,ModalModule.forRoot()
    
    
    ],
    declarations:[CreateNewFicheComponent],
    providers:[GroupManagementService],
    bootstrap:[CreateNewFicheComponent]
})

export class AppModule{

}

