"use strict";
var Entities;
(function (Entities) {
    (function (Status) {
        Status[Status["None"] = 0] = "None";
        Status[Status["Defaulted"] = 1] = "Defaulted";
        Status[Status["WatchList"] = 2] = "WatchList";
        Status[Status["Healthy"] = 3] = "Healthy";
    })(Entities.Status || (Entities.Status = {}));
    var Status = Entities.Status;
    var DataForGlobalView = (function () {
        function DataForGlobalView(ccgId, clientId, fullName, status, dateOfCreation, totalProvisionConsolidated) {
            this.ccgId = ccgId;
            this.clientId = clientId;
            this.fullName = fullName;
            this.status = status;
            this.dateOfCreation = dateOfCreation;
            this.totalProvisionConsolidated = totalProvisionConsolidated;
        }
        return DataForGlobalView;
    }());
    Entities.DataForGlobalView = DataForGlobalView;
})(Entities = exports.Entities || (exports.Entities = {}));
//# sourceMappingURL=commonEntities.js.map