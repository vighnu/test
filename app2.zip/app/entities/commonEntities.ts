export namespace Entities { 
 export interface IDataForGlobalView{
     ccgId:string;
     clientId:string;
     fullName:string;
     status:Status;
     dateOfCreation:string;
     totalProvisionConsolidated:string;
 } 

export  enum Status {
    None=0,
    Defaulted = 1,
    WatchList,
    Healthy
}

export class DataForGlobalView implements IDataForGlobalView{
    constructor(public ccgId:string,public clientId:string,
    public fullName:string,public status:Status,public dateOfCreation:string,public totalProvisionConsolidated:string){

    }
 }

}