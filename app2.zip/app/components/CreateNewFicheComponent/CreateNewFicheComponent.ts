/// <reference path="../../entities/commonEntities.ts" />
import {Component} from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
//  import { AlertModule } from 'ngx-bootstrap/alert'
 import {Entities} from '../../entities/commonEntities';  
  import {GroupManagementService} from '../../services/GlobalGroupService' 

@Component({
    selector:'create-new-fiche',
        templateUrl:'app/components/CreateNewFicheComponent/CreateNewFicheComponent.html',
        styleUrls:['app/components/CreateNewFicheComponent/CreateNewFicheComponent.css']
         
         
})
export class CreateNewFicheComponent{
 closeResult: string;
private dataForGlobalView:Entities.IDataForGlobalView ;

  constructor(private modalService: NgbModal, private groupManagementService:GroupManagementService) {
  this.dataForGlobalView= new Entities.DataForGlobalView('','','',Entities.Status.None,'','');  
  }

  open(content) {
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

validate(){
debugger;
console.log(this.dataForGlobalView.ccgId);
this.groupManagementService.setCurrentGroupId(this.dataForGlobalView.ccgId);
  }

  cancel(staticModal){
    debugger;
    this.dataForGlobalView= new Entities.DataForGlobalView('','','',Entities.Status.None,'','');
     staticModal.hide()
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}